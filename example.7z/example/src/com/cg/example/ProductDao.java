package com.cg.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProductDao {
	
		Connection con = null;
		PreparedStatement ps = null;
		public  Connection getConnection() {
			 try {
				  Class.forName("oracle.jdbc.driver.OracleDriver");
				  String url = "jdbc:oracle:thin:@localhost:1521:XE";
				  String user = "system";
				  String pass = "Capgemini123 " ;
				  con = DriverManager.getConnection(url ,user ,pass);
				  return con;
				 
			 }
			 catch (Exception e)
			 {
				 e.printStackTrace();
			 }
			 return con;
}
		
		
		public int registerUser(String username, String password, String contactno,
				String mail, String address) {
				PreparedStatement ps = null;
				Connection con = getConnection();
				String sql = "insert into customer_details values(c_id_seq.nextval,?,?,?,?,?)";

				try {
				ps = con.prepareStatement(sql);
				ps.setString(1, username);
				ps.setString(2, password);
				ps.setString(3, contactno);
				ps.setString(4, mail);
				ps.setString(5,address);
				int rs = ps.executeUpdate();
				
				return rs;
				
				}

				catch (Exception e) {
				
				// e.printStackTrace();
				return 0;
				}
		}

		public boolean validateUser(String username ,String password)
		{
			try{
		
		con=getConnection();
		String sql = "select * from user_details where password= ?";
		
			ps=con.prepareStatement(sql);
			ps.setString(1, password);
			ResultSet rs = ps.executeQuery();
			
			return rs.next();
			
		}
		catch (Exception e)
		 {
			
		 }
		 return false;
	}	
	public int addproduct(String productid,String productname,String productmodel ,String productprice )
	{
		try{
			
			con=getConnection();
			String sql = "insert into product_details values (?,?,?,?)";
			ps=con.prepareStatement(sql);
			ps.setString(1,productid);
			ps.setString(2,productname);
			ps.setString(3,productmodel);
			ps.setString(4,productprice);
			int rs = ps.executeUpdate();
			
			return rs;
			
		}
		catch (Exception e)
		 {
			
		 }
		 return 0;
			
	}
	public int editProduct(String productid,String productprice )
	{
		
		try{
			con=getConnection();
			String sql = "update product_details set p_price=? where p_id=?";
			
			ps=con.prepareStatement(sql);
			ps.setString(1,productprice);
			ps.setString(2,productid);
			
			int rs = ps.executeUpdate();
			
			return rs;
			
		}
		catch (Exception e)
		 {
			e.printStackTrace();
		 }
		 return 0;
			
	}
	public int forgot(String npassword, String cpassword, String username){

		con = getConnection();

		String sql = "update user_details set password =? where username = ?";

		try{

		ps = con.prepareStatement(sql);

		//ps.setString(1, pname );

		//ps.setString(2, pmodel );

		ps.setString(1, npassword );

		ps.setString(2, username);

		int n= ps.executeUpdate();

		return n;

		}catch(Exception e){

		}

		return 0;

		}
	public boolean validateAdmin(String username ,String password)
	{
		try{
	
	con=getConnection();
	String sql = "select * from admin_details where password= ?";
	
		ps=con.prepareStatement(sql);
		ps.setString(1, password);
		ResultSet rs = ps.executeQuery();
		
		return rs.next();
		
	}
	catch (Exception e)
	 {
		
	 }
	 return false;
}	
	

	}
	


package com.cg.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ForgotPassword
 */
@WebServlet("/ForgotPassword")
public class ForgotPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		  PrintWriter out = response.getWriter();
		  //String Productname = request.getParameter("pname");
		  //String Productmodel = request.getParameter("model");
		  String username = request.getParameter("user");
		  String NewPassword = request.getParameter("npass");
		  String OldPassword = request.getParameter("opass");
		  

		  ProductDao dao = new ProductDao();
		  int n = dao.forgot(NewPassword,OldPassword,username);
		  out.println(n);
		  if(n>0){
		   out.println("<b style='color:green'>Update Successfull.</b>");
		   RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
		   rd.forward(request, response);
		  }else{
		   RequestDispatcher rd = request.getRequestDispatcher("forgotpassword.jsp?emsg=something went wrong, register again");
		   rd.include(request, response);
		  }
		 }

		 }